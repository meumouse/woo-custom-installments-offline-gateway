/**
 * Display options on click toggle switch
 * 
 * @since 1.0.0
 */
jQuery(function($) {
    // Reusable function for toggling visibility based on checkbox state
    function toggleVisibility(checkboxSelector, elementSelector) {
        var parentRow = $(elementSelector).closest('tr');
        if ($(checkboxSelector).prop('checked')) {
            parentRow.show();
        } else {
            parentRow.hide();
        }
    }

    // Initial visibility check
    toggleVisibility('#woocommerce_woo_custom_installments_offline_gateway_enable_debit_card_badges', '#woocommerce_woo_custom_installments_offline_gateway_debit_card');

    // Change visibility on checkbox click
    $('#woocommerce_woo_custom_installments_offline_gateway_enable_debit_card_badges').click(function() {
        toggleVisibility('#woocommerce_woo_custom_installments_offline_gateway_enable_debit_card_badges', '#woocommerce_woo_custom_installments_offline_gateway_debit_card');
    });

    // Initial visibility check
    toggleVisibility('#woocommerce_woo_custom_installments_offline_gateway_enable_credit_card_badges', '#woocommerce_woo_custom_installments_offline_gateway_credit_card');

    // Change visibility on checkbox click
    $('#woocommerce_woo_custom_installments_offline_gateway_enable_credit_card_badges').click(function() {
        toggleVisibility('#woocommerce_woo_custom_installments_offline_gateway_enable_credit_card_badges', '#woocommerce_woo_custom_installments_offline_gateway_credit_card');
    });
});