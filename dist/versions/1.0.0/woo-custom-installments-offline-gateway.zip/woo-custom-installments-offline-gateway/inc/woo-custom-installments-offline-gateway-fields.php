<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Gateway fields for Woo_Custom_Installments_Offline_Gateway
 * 
 * @since 1.0.0
 * @return array
 * @package MeuMouse.com
 */

$shipping_methods = array();

foreach ( WC()->shipping()->load_shipping_methods() as $method ) {
    $title = empty( $method->method_title ) ? ucfirst( $method->id ) : $method->method_title;
    $shipping_methods[ strtolower( $method->id ) ] = esc_html( $title );
}

$this->form_fields = array(
    'enabled' => array(
        'title' => __( 'Ativar/Desativar', 'woo-custom-installments-offline-gateway' ),
        'type' => 'checkbox',
        'class' => 'toggle-switch',
        'label' => __( 'Habilitar forma de pagamento', 'woo-custom-installments-offline-gateway' ),
        'default' => 'yes'
    ),
    'title' => array(
        'title' => __( 'Título da forma de pagamento', 'woo-custom-installments-offline-gateway' ),
        'type' => 'text',
        'class' => 'form-control',
        'description' => __( 'Título da forma de pagamento que será exibida na finalização de compra.', 'woo-custom-installments-offline-gateway' ),
        'default' => __( 'Cartões de crédito', 'woo-custom-installments-offline-gateway' ),
        'desc_tip' => true,
    ),
    'description' => array(
        'title' => __( 'Descrição (Opcional)', 'woo-custom-installments-offline-gateway' ),
        'type' => 'textarea',
        'class' => 'form-control',
        'description' => __( 'Informe ao cliente algum detalhe que seja importante.', 'woo-custom-installments-offline-gateway' ),
        'default' => __( 'Selecione o parcelamento do seu pedido.', 'woo-custom-installments-offline-gateway' ),
        'desc_tip' => true,
    ),
    'note_enabled' => array(
        'title' => __( 'Ativar/Desativar', 'woo-custom-installments-offline-gateway' ),
        'type' => 'checkbox',
        'class' => 'toggle-switch',
        'label' => __( 'Exibir os detalhes de pagamento nas observações do pedido.', 'woo-custom-installments-offline-gateway' ),
        'default' => 'yes'
    ),
    'status' => array(
        'title' => __( 'Status do pedido', 'woo-custom-installments-offline-gateway' ),
        'type' => 'select',
        'class' => 'form-select',
        'css' => 'width: 400px;',
        'desc_tip' 	=> __( 'Selecione um status para ser gerado no ato da compra online.', 'woo-custom-installments-offline-gateway' ),
        'options' => array(
            'wc-pending' =>  __( 'Aguardando (Padrão)', 'woo-custom-installments-offline-gateway' ),
            'wc-processing' =>  __( 'Processando', 'woo-custom-installments-offline-gateway' ),
            'wc-completed' =>  __( 'Concluído', 'woo-custom-installments-offline-gateway' ),
        ),
        'default' => 'wc-pending',
    ),
    /*
    'enable_for_methods' => array(
        'title' => __( 'Ativar para formas de entrega', 'woo-custom-installments-offline-gateway' ),
        'type' => 'multiselect',
        'class' => 'wc-enhanced-select',
        'css' => 'width: 400px;',
        'default' => '',
        'description' => __( 'Se desejar que a forma de pagamento na entrega seja disponível apenas para determinadas métodos, selecione-as aqui.', 'woo-custom-installments-offline-gateway' ),
        'options' => $shipping_methods,
        'desc_tip' => true,
        'custom_attributes' => array(
        'data-placeholder' => __( 'Permitir apenas para as formas de entrega', 'woo-custom-installments-offline-gateway' )
        )
    ),
    'enable_for_methods_all' => array(
		'title' => __( 'Ativar/Desativar', 'woo-payment-on-delivery' ),
		'type' => 'checkbox',
        'class' => 'toggle-switch',
		'label' => __( 'Ativar para todos os métodos de entrega ou para produtos virtuais.', 'woo-custom-installments-offline-gateway' ),
		'default' => 'no'
	),*/
);