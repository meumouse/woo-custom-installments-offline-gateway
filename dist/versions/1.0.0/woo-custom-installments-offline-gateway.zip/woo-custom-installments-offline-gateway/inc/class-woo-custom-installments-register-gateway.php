<?php

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit; 
}

/**
 * Allow your customers to pay with cash, Pix, credit and debit cards on delivery.
 *
 * @class   Woo_Custom_Installments_Register_Offline_Gateway
 * @extends WC_Payment_Gateway
 * @since   1.0.0
 * @package MeuMouse.com
 */
class Woo_Custom_Installments_Register_Offline_Gateway extends WC_Payment_Gateway {

    public function __construct() {
        $this->setup_properties();

        add_filter( 'woocommerce_payment_gateways', array( $this, 'register_class_offline_gateway' ) );
        add_filter( 'woocommerce_available_payment_gateways', array( $this, 'check_shipping_methods' ) );
        add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

        // load the settings
        $this->init_form_fields();
        $this->init_settings();	
                
        // get settings
        $this->title = $this->get_option( 'title' );
        $this->description = $this->get_option( 'description' );
        $this->status = $this->get_option( 'status' );
        $this->note_enabled	= $this->get_option( 'note_enabled' );
    //    $this->paymenttypes	= $this->get_option( 'paymenttypes' );
    //    $this->notice_money = $this->get_option( 'notice_money' );
    //    $this->pix_key = $this->get_option( 'pix_key_type' );
    //    $this->pix_key = $this->get_option( 'pix_key' );
    //    $this->pix_description = $this->get_option( 'pix_description' );
    //    $this->debit_card = $this->get_option( 'debit_card' );
    //    $this->credit_card = $this->get_option( 'credit_card' );
    //    $this->enable_debit_card_badges = $this->get_option( 'enable_debit_card_badges' );
    //    $this->enable_credit_card_badges = $this->get_option( 'enable_credit_card_badges' );
    //    $this->enable_for_methods_all = $this->get_option( 'enable_for_methods_all' );
        $this->enable_for_methods = $this->get_option( 'enable_for_methods', array() );
    }


    /**
	 * Setup general properties for the gateway
     * 
     * @since 1.0.0
     * @return void
     * @package MeuMouse.com
	 */
	protected function setup_properties() {
        $this->id = 'woo_custom_installments_offline_gateway';
        $this->has_fields = true;
        $this->enabled = 'no';
        $this->method_title = __( 'Parcelas Customizadas para WooCommerce - Pagamento offline', 'woo-custom-installments-offline-gateway' );
        $this->method_description = __( 'Permita que seus clientes paguem com cartões de crédito na entrega.', 'woo-custom-installments-offline-gateway' );
        $this->supports = array(
            'products',
        );
	}


    /**
     * Include gateway admin fields
     * 
     * @since 1.0.0
     * @return void
     * @package MeuMouse.com
     */
    public function init_form_fields() {
        require WCI_OFFLINE_GATEWAY_DIR . 'inc/woo-custom-installments-offline-gateway-fields.php';
    }


    /**
     * Display gateway options
     * 
     * @since 1.0.0
     * @return string
     * @package MeuMouse.com
     */
    public function admin_options() {
        echo '<h3> ' . __( 'Parcelas Customizadas para WooCommerce - Pagamento offline', 'woo-custom-installments-offline-gateway' ) . ' </h3>';	
    //    echo var_dump( get_option( 'woo-custom-installments-setting' ) );
        echo var_dump( $this->enable_for_methods );
        echo '<table class="form-table" id="settings-block">';							
        $this->generate_settings_html();
        echo '</table>';
    }

    
    /**
     * Enqueue admin scripts
     * 
     * @since 1.0.0
     * @return void
     * @package MeuMouse.com
     */
    public function enqueue_admin_scripts() {
        $url = $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
        $version = Woo_Custom_Installments_Offline_Gateway()->version;
    
        if ( false !== strpos( $url, 'admin.php?page=wc-settings&tab=checkout&section=woo_custom_installments_offline_gateway' ) ) {
            wp_enqueue_style( 'woo-custom-installments-offline-gateway-admin-styles', WCI_OFFLINE_GATEWAY_URL . 'assets/css/wci-offline-gateway-admin-styles.css', array(), $version );
        //    wp_enqueue_script( 'woo-custom-installments-offline-gateway-admin-scripts', WCI_OFFLINE_GATEWAY_URL . 'assets/js/admin-scripts.js', array('jquery'), $version );
        }
    }


    /**
     * Enqueue scripts on checkout
     * 
     * @since 1.0.0
     * @return void
     * @package MeuMouse.com
     */
    public function enqueue_scripts() {
        $version = Woo_Custom_Installments_Offline_Gateway()->version;
    
        if ( is_checkout() ) {
            wp_enqueue_style( 'woo-custom-installments-offline-gateway-checkout-styles', WCI_OFFLINE_GATEWAY_URL . 'assets/css/wci-offline-gateway-styles.css', array(), $version );
        }
    }
    
    
    /**
     * Register class
     * 
     * @since 1.0.0
     * @return void
     * @package MeuMouse.com
     */
    public function register_class_offline_gateway( $gateways ) {
        $gateways[] = 'Woo_Custom_Installments_Register_Offline_Gateway';
        return $gateways;
	}


    /**
     * Check shipping methods for allowed gateway
     * 
     * @since 1.0.0
     * @return string
     * @package MeuMouse.com
     */
    public function check_shipping_methods( $available_gateways ) {
        // Se não houver métodos de envio permitidos, não fazemos nenhuma verificação
        if ( empty( $this->enable_for_methods ) ) {
            return $available_gateways;
        }
    
        if ( WC()->session ) {
            var_dump( $this->enable_for_methods );
            $chosen_shipping_methods = WC()->session->get( 'chosen_shipping_methods' );
            $selected_shipping_method = reset( $chosen_shipping_methods );
        
            // Verifica se o método selecionado está na lista de métodos permitidos
            if ( in_array( $selected_shipping_method, $this->enable_for_methods ) ) {
                return $available_gateways;
            }
            var_dump('Method allowed');
        }
    
        // Remove o gateway do array de gateways disponíveis.
        unset( $available_gateways['woo_custom_installments_offline_gateway'] );
        return $available_gateways;
    }
    

    /**
     * Save order details
     * 
     * @since 1.0.0
     * @return void
     * @package MeuMouse.com
     */
    public function process_payment( $order_id ) {
        global $woocommerce;

        $order = wc_get_order( $order_id );
        $selected_installment = sanitize_text_field( $_POST['woo_custom_installments_offline'] );

        $status_names = array(
            'wc-pending' =>  __( 'Aguardando pagamento', 'woo-custom-installments-offline-gateway' ),
            'wc-processing' =>  __( 'Processando', 'woo-custom-installments-offline-gateway' ),
            'wc-completed' =>  __( 'Concluído', 'woo-custom-installments-offline-gateway' ),
        );
    
        $selected_status_name = isset( $status_names[ $this->status ] ) ? $status_names[ $this->status ] : '';

        // update order status
        $order->update_status( $this->status, __( "Pedido $selected_status_name via Parcelas Customizadas para WooCommerce - Gateway de pagamento offline", 'woo-custom-installments-offline-gateway' ) );
        
        // save installment selected on post meta
        if ( ! empty( $_POST['selected_installment_text'] ) ) {
            $selected_installment_text = sanitize_text_field( $_POST['selected_installment_text'] );
            update_post_meta( $order_id, 'selected_installment_text', $selected_installment_text );

            // Add a note to the order with the selected installment information 
            if ( $this->note_enabled == 'yes' ) {
                $note = sprintf( "Parcela selecionada: %s", $selected_installment_text );
                $order->add_order_note( $note );
            }
        }

        // redirect for thankyou page
        return array(
            'result' => 'success',
            'redirect' => $this->get_return_url( $order )
        );
    }


    /**
     * Include fields on payment method
     * 
     * @since 1.0.0
     * @return void
     * @package MeuMouse.com
     */
    public function payment_fields() {
        global $woocommerce;
    
        // get array options of Woo_Custom_Installments
        $options = get_option( 'woo-custom-installments-setting' );
        $custom_fee_installments = $options['custom_fee_installments'];
        $get_min_value_installment = $options['min_value_installments'];
        $get_max_installments = $options['max_qtd_installments'];
        $get_max_installments_without_fee = $options['max_qtd_installments_without_fee'];
        $cart = $woocommerce->cart;
        $order_total = $cart->total;
    
        echo '<div class="woo-custom-installments-gateway-fields">';
        echo '<select name="woo_custom_installments_offline" id="custom_installments">';
    
        $installments_info = array();
        $customFeeInstallments = get_option('woo_custom_installments_custom_fee_installments');
        $customFeeInstallments = maybe_unserialize( $customFeeInstallments );
    
        for ( $i = 1; $i <= $get_max_installments; $i++ ) {
            $interest_rate = 0; // start without fee
            $fee = isset( $custom_fee_installments[ $i ]['amount'] ) ? $custom_fee_installments[ $i ]['amount'] : '0';
            $installment_amount = $fee === '0' ? $options['text_without_fee_installments'] : $options['text_with_fee_installments'];
    
            if ( $fee === '0' ) {
                $installment_price = $order_total / $i;
            } else {
                if ( isset( $options['set_fee_per_installment'] ) && $options['set_fee_per_installment'] === 'yes' ) {
                    $percentage = floatval( wc_format_decimal( $fee ) ) / 100.00;
                    $installment_price = ( $order_total * $percentage + $order_total ) / $i;
                } else {
                    $percentage = floatval( wc_format_decimal( $options['fee_installments_global'] ) ) / 100.00;
                    $installment_price = ( $order_total * $percentage * ( ( 1 + $percentage ) ** $i ) ) / ( ( ( 1 + $percentage ) ** $i ) - 1 );
                }
            }
    
            $display_value = wc_price( $installment_price );
            $installments_info[] = array(
                'installment_price' => $installment_price,
                'installment_text' => $i . 'x de ' . $display_value . ' ' . $installment_amount,
            );
        }
    
        foreach ( $installments_info as $index => $installment ) {
            if ( $installment['installment_price'] >= $get_min_value_installment ) {
                echo '<option value="installment-' . ( $index + 1 ) . '" data-text="' . esc_attr( strip_tags( $installment['installment_text'] ) ) . '">' . $installment['installment_text'] . '</option>';
            }
        }
    
        echo '</select>';

        // add input hidden for save installment selected 
        echo '<input type="hidden" name="selected_installment_text" id="selected_installment_text" value="">';
        echo '<p class="woo-custom-installments-description-gateway">' . $this->description . '</p>';
        echo '</div>';

        ?>
        <script>
            jQuery(document).ready(function($) {
                // Quando uma opção de parcela for selecionada
                $('#custom_installments').change(function() {
                    var selectedOption = $(this).find(':selected');
                    var selectedText = selectedOption.data('text');
                    
                    // Atualiza o valor do campo oculto com o texto da parcela selecionada
                    $('#selected_installment_text').val(selectedText);
                });
            });
        </script>
        <?php
    }

}

new Woo_Custom_Installments_Register_Offline_Gateway();