<?php

/**
 * Plugin Name: 			Parcelas Customizadas para WooCommerce - Gateway de pagamento offline
 * Description: 			Complemento do plugin Parcelas Customizadas para WooCommerce, que permite adicionar uma nova forma de pagamento offline no WooCommerce, para usuários selecionarem parcelas na finalização de compra.
 * Plugin URI: 				https://meumouse.com/plugins/parcelas-customizadas-para-woocommerce/
 * Author: 					MeuMouse.com
 * Author URI: 				https://meumouse.com/
 * Version: 				1.3.0
 * WC requires at least: 	5.0.0
 * WC tested up to: 		8.2.0
 * Requires PHP: 			7.2
 * Tested up to:      		6.3.2
 * Text Domain: 			woo-custom-installments-offline-gateway
 * Domain Path: 			/languages
 * License: 				GPL2
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

// Define WCI_OFFLINE_GATEWAY_PLUGIN_FILE.
if ( ! defined( 'WCI_OFFLINE_GATEWAY_PLUGIN_FILE' ) ) {
	define( 'WCI_OFFLINE_GATEWAY_PLUGIN_FILE', __FILE__ );
}
  
/**
 * Woo_Custom_Installments_Offline_Gateway
 *
 * @class Woo_Custom_Installments_Offline_Gateway
 * @version 1.0.0
 * @since 1.0.0
 * @package MeuMouse.com
 */
class Woo_Custom_Installments_Offline_Gateway {

		/**
		 * Woo_Custom_Installments_Offline_Gateway The single instance of Woo_Custom_Installments_Offline_Gateway.
		 *
		 * @var object
		 * @since 1.0.0
		 */
		private static $instance = null;

		/**
		 * The slug
		 *
		 * @var string
		 * @since 1.0.0
		 */
		public static $slug = 'woo-custom-installments-offline-gateway';

		/**
		 * The version number
		 *
		 * @var string
		 * @since 1.0.0
		 */
		public static $version = '1.3.0';

		/**
		 * Constructor function
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function __construct() {
			$this->setup_constants();

			add_action( 'init', array( $this, 'load_plugin_textdomain' ), -1 );
			add_action( 'plugins_loaded', array( $this, 'woo_custom_installments_offline_gateway_load_checker' ), 5 );
		}

		
		public function woo_custom_installments_offline_gateway_load_checker() {
			if ( !function_exists( 'is_plugin_active' ) ) {
				include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
			}
		
			// check if WooCommerce is active
			if ( is_plugin_active( 'woo-custom-installments/woo-custom-installments.php' ) ) {
				add_action( 'plugins_loaded', array( $this, 'setup_includes' ), 10 );
				add_filter( 'plugin_action_links_' . WCI_OFFLINE_GATEWAY_BASE, array( $this, 'woo_custom_installments_offline_gateway_plugin_links' ), 10, 4 );
			} else {
				deactivate_plugins( 'woo-custom-installments-offline-gateway/woo-custom-installments-offline-gateway.php' );
				add_action( 'admin_notices', array( $this, 'woo_custom_installments_offline_gateway_wc_deactivate_notice' ) );
			}
		}


		/**
		 * Main Woo_Custom_Installments_Offline_Gateway Instance
		 *
		 * Ensures only one instance of Woo_Custom_Installments_Offline_Gateway is loaded or can be loaded.
		 *
		 * @since 1.0.0
		 * @static
		 * @see Woo_Custom_Installments_Offline_Gateway()
		 * @return Main Woo_Custom_Installments_Offline_Gateway instance
		 */
		public static function run() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}


		/**
		 * Define constant if not already set.
		 *
		 * @param string      $name  Constant name.
		 * @param string|bool $value Constant value.
		 */
		private function define( $name, $value ) {
			if ( ! defined( $name ) ) {
				define( $name, $value );
			}
		}


		/**
		 * Setup plugin constants
		 *
		 * @since  1.0.0
		 * @return void
		 */
		public function setup_constants() {
			$this->define( 'WCI_OFFLINE_GATEWAY_BASE', plugin_basename( __FILE__ ) );
			$this->define( 'WCI_OFFLINE_GATEWAY_DIR', plugin_dir_path( __FILE__ ) );
			$this->define( 'WCI_OFFLINE_GATEWAY_URL', plugin_dir_url( __FILE__ ) );
			$this->define( 'WCI_OFFLINE_GATEWAY_FILE', __FILE__ );
			$this->define( 'WCI_OFFLINE_GATEWAY_ABSPATH', dirname( WCI_OFFLINE_GATEWAY_FILE ) . '/' );
			$this->define( 'WCI_OFFLINE_GATEWAY_VERSION', self::$version );
			$this->define( 'WCI_OFFLINE_GATEWAY_SLUG', self::$slug );
		}


		/**
		 * What type of request is this?
		 *
		 * @param  string $type admin, ajax, cron or wciend.
		 * @return bool
		 */
		private function is_request( $type ) {
			switch ( $type ) {
				case 'admin':
					return is_admin();
				case 'ajax':
					return defined( 'DOING_AJAX' );
				case 'cron':
					return defined( 'DOING_CRON' );
			}
		}


		/**
		 * Include required files
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function setup_includes() {
            
			/**
			 * Register offline gateway
			 * 
			 * @since 1.0.0
			 */
            include_once WCI_OFFLINE_GATEWAY_DIR . 'inc/class-woo-custom-installments-register-gateway.php';

			/**
			 * Include functions
			 * 
			 * @since 1.1.0
			 */
            include_once WCI_OFFLINE_GATEWAY_DIR . 'inc/woo-custom-installments-offline-gateway-functions.php';

			/**
			 * Update checker
			 * 
			 * @since 1.3.0
			 */
            include_once WCI_OFFLINE_GATEWAY_DIR . 'inc/class-woo-custom-installments-offline-gateway-updater.php';
		}


		/**
		 * Notice if WooCommerce is deactivate
		 */
		public function woo_custom_installments_offline_gateway_wc_deactivate_notice() {
			if ( !current_user_can( 'install_plugins' ) ) { 
				return;
			}

			echo '<div class="notice is-dismissible error">
					<p>' . __( '<strong>Parcelas Customizadas para WooCommerce - Gateway de pagamento offline</strong> requer que <strong>Parcelas Customizadas para WooCommerce</strong> esteja instalado e ativado.', 'woo-custom-installments-offline-gateway' ) . '</p>
				</div>';
		}


		/**
		 * Plugin action links
		 * 
		 * @since 1.0.0
		 * @return array
		 */
		public function woo_custom_installments_offline_gateway_plugin_links( $action_links ) {
			$plugins_links = array(
				'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=woo_custom_installments_offline_gateway' ) . '">'. __( 'Configurar', 'woo-custom-installments-offline-gateway' ) .'</a>'
			);

			return array_merge( $plugins_links, $action_links );
		}


		/**
		 * Load the plugin text domain for translation.
		 */
		public static function load_plugin_textdomain() {
			load_plugin_textdomain( 'woo-custom-installments-offline-gateway', false, dirname( WCI_OFFLINE_GATEWAY_BASE ) . '/languages/' );
		}

		/**
		 * Get the plugin url.
		 *
		 * @return string
		 */
		public function plugin_url() {
			return untrailingslashit( plugins_url( '/', WCI_OFFLINE_GATEWAY_PLUGIN_FILE ) );
		}

		/**
		 * Cloning is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __clone() {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Trapaceando?', 'woo-custom-installments-offline-gateway' ), '1.0.0' );
		}

		/**
		 * Unserializing instances of this class is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __wakeup() {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Trapaceando?', 'woo-custom-installments-offline-gateway' ), '1.0.0' );
		}

}

/**
 * Initialise the plugin
 */
Woo_Custom_Installments_Offline_Gateway::run();