<?php

/**
 * Plugin Name: 			Parcelas Customizadas para WooCommerce - Gateway de pagamento offline
 * Description: 			Complemento do plugin Parcelas Customizadas para WooCommerce, que permite adicionar uma nova forma de pagamento offline no WooCommerce, para usuários selecionarem parcelas na finalização de compra.
 * Plugin URI: 				https://meumouse.com/plugins/parcelas-customizadas-para-woocommerce/
 * Author: 					MeuMouse.com
 * Author URI: 				https://meumouse.com/
 * Version: 				1.1.0
 * WC requires at least: 	5.0.0
 * WC tested up to: 		8.0.0
 * Requires PHP: 			7.2
 * Tested up to:      		6.2.2
 * Text Domain: 			woo-custom-installments-offline-gateway
 * Domain Path: 			/languages
 * License: 				GPL2
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit; 
}

// Define WCI_OFFLINE_GATEWAY_PLUGIN_FILE.
if ( ! defined( 'WCI_OFFLINE_GATEWAY_PLUGIN_FILE' ) ) {
	define( 'WCI_OFFLINE_GATEWAY_PLUGIN_FILE', __FILE__ );
}

use YahnisElsts\PluginUpdateChecker\v5\PucFactory;
  
/**
 * Woo_Custom_Installments_Offline_Gateway
 *
 * @class Woo_Custom_Installments_Offline_Gateway
 * @version 1.0.0
 * @since 1.0.0
 * @package MeuMouse.com
 */
class Woo_Custom_Installments_Offline_Gateway {

		/**
		 * Woo_Custom_Installments_Offline_Gateway The single instance of Woo_Custom_Installments_Offline_Gateway.
		 *
		 * @var object
		 * @since 1.0.0
		 */
		private static $instance = null;

		/**
		 * The token
		 *
		 * @var string
		 * @since 1.0.0
		 */
		public $token;

		/**
		 * The version number
		 *
		 * @var string
		 * @since 1.0.0
		 */
		public $version;

		/**
		 * Constructor function
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function __construct() {
			$this->token = 'woo-custom-installments-offline-gateway';
			$this->version = '1.1.0';
			
			add_action( 'plugins_loaded', array( $this, 'woo_custom_installments_offline_gateway_load_checker' ), 5 );
		}
		
		public function woo_custom_installments_offline_gateway_load_checker() {
			if ( !function_exists( 'is_plugin_active' ) ) {
				include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
			}
		
			// check if WooCommerce is active
			if ( is_plugin_active( 'woo-custom-installments/woo-custom-installments.php' ) ) {
				add_action( 'init', array( $this, 'load_plugin_textdomain' ), -1 );
				add_action( 'plugins_loaded', array( $this, 'setup_constants' ), 15 );
				add_action( 'plugins_loaded', array( $this, 'setup_includes' ), 20 );
				add_action( 'plugins_loaded', array( $this, 'woo_custom_installments_offline_gateway_update_checker' ), 30 );
				add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( $this, 'woo_custom_installments_offline_gateway_plugin_links' ), 10, 4 );

			} else {
				deactivate_plugins( 'woo-custom-installments-offline-gateway/woo-custom-installments-offline-gateway.php' );
				add_action( 'admin_notices', array( $this, 'woo_custom_installments_offline_gateway_wc_deactivate_notice' ) );
			}
		}

		/**
		 * Main Woo_Custom_Installments_Offline_Gateway Instance
		 *
		 * Ensures only one instance of Woo_Custom_Installments_Offline_Gateway is loaded or can be loaded.
		 *
		 * @since 1.0.0
		 * @static
		 * @see Woo_Custom_Installments_Offline_Gateway()
		 * @return Main Woo_Custom_Installments_Offline_Gateway instance
		 */
		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Setup plugin constants
		 *
		 * @since  1.0.0
		 * @return void
		 */
		public function setup_constants() {

            // WCI = Woo Custom Installments

			// Plugin Folder Path.
			if ( ! defined( 'WCI_OFFLINE_GATEWAY_DIR' ) ) {
				define( 'WCI_OFFLINE_GATEWAY_DIR', plugin_dir_path( __FILE__ ) );
			}

			// Plugin Folder URL.
			if ( ! defined( 'WCI_OFFLINE_GATEWAY_URL' ) ) {
				define( 'WCI_OFFLINE_GATEWAY_URL', plugin_dir_url( __FILE__ ) );
			}

			// Plugin Root File.
			if ( ! defined( 'WCI_OFFLINE_GATEWAY_FILE' ) ) {
				define( 'WCI_OFFLINE_GATEWAY_FILE', __FILE__ );
			}

			$this->define( 'WCI_OFFLINE_GATEWAY_ABSPATH', dirname( WCI_OFFLINE_GATEWAY_FILE ) . '/' );
			$this->define( 'WCI_OFFLINE_GATEWAY_VERSION', $this->version );
		}


		/**
		 * Define constant if not already set.
		 *
		 * @param string      $name  Constant name.
		 * @param string|bool $value Constant value.
		 */
		private function define( $name, $value ) {
			if ( ! defined( $name ) ) {
				define( $name, $value );
			}
		}


		/**
		 * What type of request is this?
		 *
		 * @param  string $type admin, ajax, cron or wciend.
		 * @return bool
		 */
		private function is_request( $type ) {
			switch ( $type ) {
				case 'admin':
					return is_admin();
				case 'ajax':
					return defined( 'DOING_AJAX' );
				case 'cron':
					return defined( 'DOING_CRON' );
			}
		}


		/**
		 * Include required files
		 *
		 * @since  1.0.0
		 * @return void
		 */
		public function setup_includes() {
            
			/**
			 * Register offline gateway
			 * 
			 * @since 1.0.0
			 */
            include_once WCI_OFFLINE_GATEWAY_DIR . 'inc/class-woo-custom-installments-register-gateway.php';

			/**
			 * Include functions
			 * 
			 * @since 1.1.0
			 */
            include_once WCI_OFFLINE_GATEWAY_DIR . 'inc/woo-custom-installments-offline-gateway-functions.php';
		}


		/**
		 * Notice if WooCommerce is deactivate
		 */
		public function woo_custom_installments_offline_gateway_wc_deactivate_notice() {
			if ( !current_user_can( 'install_plugins' ) ) { return; }

			echo '<div class="notice is-dismissible error">
					<p>' . __( '<strong>Parcelas Customizadas para WooCommerce - Gateway de pagamento offline</strong> requer que <strong>Parcelas Customizadas para WooCommerce</strong> esteja instalado e ativado.', 'woo-custom-installments-offline-gateway' ) . '</p>
				</div>';
		}


		/**
		 * Plugin action links
		 * 
		 * @since 1.0.0
		 * @return array
		 */
		public function woo_custom_installments_offline_gateway_plugin_links( $action_links ) {
			$plugins_links = array(
				'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=woo_custom_installments_offline_gateway' ) . '">'. __( 'Configurar', 'woo-custom-installments-offline-gateway' ) .'</a>',
				'<a href="https://meumouse.com/docs/plugins/parcelas-customizadas-para-woocommerce/" target="_blank">'. __( 'Ajuda', 'woo-custom-installments-offline-gateway' ) .'</a>'
			);

			return array_merge( $plugins_links, $action_links );
		}


		/**
		 * Plugin update checker
		 * 
		 * @since 1.0.0
		 */
		public function woo_custom_installments_offline_gateway_update_checker() {
			require WCI_OFFLINE_GATEWAY_DIR . 'inc/updater/plugin-update-checker.php';

			$myUpdateChecker = PucFactory::buildUpdateChecker( 'https://raw.githubusercontent.com/meumouse/woo-custom-installments-offline-gateway/main/update-checker/update-checker.json', __FILE__, 'woo-custom-installments-offline-gateway' );
		}


		/**
		 * Load the plugin text domain for translation.
		 */
		public static function load_plugin_textdomain() {
			load_plugin_textdomain( 'woo-custom-installments-offline-gateway', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
		}

		/**
		 * Get the plugin url.
		 *
		 * @return string
		 */
		public function plugin_url() {
			return untrailingslashit( plugins_url( '/', WCI_OFFLINE_GATEWAY_PLUGIN_FILE ) );
		}

		/**
		 * Cloning is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __clone() {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Trapaceando?', 'woo-custom-installments-offline-gateway' ), '1.0.0' );
		}

		/**
		 * Unserializing instances of this class is forbidden.
		 *
		 * @since 1.0.0
		 */
		public function __wakeup() {
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Trapaceando?', 'woo-custom-installments-offline-gateway' ), '1.0.0' );
		}

}

/**
 * Returns the main instance of Woo_Custom_Installments_Offline_Gateway to prevent the need to use globals.
 *
 * @since  1.0.0
 * @return object Woo_Custom_Installments_Offline_Gateway
 */
function Woo_Custom_Installments_Offline_Gateway() { //phpcs:ignore WordPress.NamingConventions.ValidFunctionName.FunctionNameInvalid
	return Woo_Custom_Installments_Offline_Gateway::instance();
}

/**
 * Initialise the plugin
 */
Woo_Custom_Installments_Offline_Gateway();