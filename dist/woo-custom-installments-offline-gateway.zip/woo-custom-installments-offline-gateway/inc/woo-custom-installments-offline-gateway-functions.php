<?php

/**
 * Add new line on table order details with order total installments
 * 
 * @since 1.1.0
 * @return array
 * @package MeuMouse.com
 */
function add_installment_total_to_order_details($total_rows, $order, $tax_display) {
    $selected_installment_text_without_fee = get_post_meta($order->get_id(), 'selected_installment_text_without_fee', true);

    if ( $selected_installment_text_without_fee ) {
        $total_rows['installment_total'] = array(
            'label' => __( 'Total parcelado', 'woo-custom-installments-offline-gateway' ),
            'value' => $selected_installment_text_without_fee,
        );
    }

    return $total_rows;
}

add_filter('woocommerce_get_order_item_totals', 'add_installment_total_to_order_details', 10, 3);


/**
 * Update order total with selected installment on thankyou page
 * 
 * @since 1.1.0
 * @return void
 * @package MeuMouse.com
 */
function update_order_total_for_thank_you_page($total, $order) {
    $total_with_installment = get_post_meta($order->get_id(), 'order_total_with_selected_installment', true);

    if ($total_with_installment) {
        return wc_format_decimal($total_with_installment);
    }

    return $total;
}

add_filter('woocommerce_order_get_total', 'update_order_total_for_thank_you_page', 10, 2);


/**
 * Replace order total with selected installment on table order details
 * 
 * @since 1.1.0
 * @return string
 * @package MeuMouse.com
 */
function custom_display_order_total_with_installment_in_order_details($total_rows, $order) {
    $total_with_installment = get_post_meta($order->get_id(), 'order_total_with_selected_installment', true);

    if ($total_with_installment) {
        $total_rows['order_total']['value'] = wc_price($total_with_installment);
    }

    return $total_rows;
}

add_filter('woocommerce_get_order_item_totals', 'custom_display_order_total_with_installment_in_order_details', 10, 2);


/**
 * Update order total for admin
 * 
 * @since 1.1.0
 * @return string
 * @package MeuMouse.com
 */
function update_admin_order_total($formatted_total, $order) {
    $total_with_installment = get_post_meta($order->get_id(), 'order_total_with_selected_installment', true);

    if ($total_with_installment) {
        return wc_price(wc_format_decimal($total_with_installment));
    }

    return $formatted_total;
}

add_filter('woocommerce_admin_order_total', 'update_admin_order_total', 10, 2);